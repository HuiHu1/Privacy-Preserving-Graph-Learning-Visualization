from dgl.data import CoraGraphDataset
from gnnlens import Writer
import torch.nn as nn
from captum.attr import IntegratedGradients
from dgl.nn import GraphConv
from functools import partial
import torch.nn.functional as F
import torch
import dgl

dataset = CoraGraphDataset()
graph = dataset[0]
nlabels = graph.ndata['label']
num_classes = dataset.num_classes
writer = Writer('Subgraph')
writer.add_graph(name='Cora', graph=graph,
                 nlabels=nlabels, num_nlabel_types=num_classes)

class GCN(nn.Module):
    def __init__(self,
                 in_feats,
                 num_classes):
        super(GCN, self).__init__()
        self.conv = GraphConv(in_feats, num_classes)

    def forward(self, h, g):
        # Interchange the order of g and h due to the behavior of partial
        return self.conv(g, h)

# Required by IntegratedGradients
h = graph.ndata['feat'].clone().requires_grad_(True)
model = GCN(h.shape[1], num_classes)
ig = IntegratedGradients(partial(model.forward, g=graph))
# Attribute the predictions for node class 0 to the input features
feat_attr = ig.attribute(h, target=0, internal_batch_size=graph.num_nodes(), n_steps=50)
node_weights = feat_attr.abs().sum(dim=1)
node_weights = (node_weights - node_weights.min()) / node_weights.max()
def extract_subgraph(g, node):
    seed_nodes = [node]
    sg = dgl.in_subgraph(g, seed_nodes)
    src, dst = sg.edges()
    seed_nodes = torch.cat([src, dst]).unique()
    sg = dgl.in_subgraph(g, seed_nodes, relabel_nodes=True)
    return sg

graph.ndata['weight'] = node_weights
graph.edata['weight'] = torch.randn(graph.num_edges(),)
first_subgraph = extract_subgraph(graph, 0)
writer.add_subgraph(graph_name='Cora', subgraph_name='IntegratedGradients', node_id=0, 
                    subgraph_nids=first_subgraph.ndata[dgl.NID],
                    subgraph_eids=first_subgraph.edata[dgl.EID],
                    subgraph_nweights=first_subgraph.ndata['weight'],
                    subgraph_eweights=first_subgraph.edata['weight'])

second_subgraph = extract_subgraph(graph, 1)
writer.add_subgraph(graph_name='Cora', subgraph_name='IntegratedGradients', node_id=1,
                    subgraph_nids=second_subgraph.ndata[dgl.NID],
                    subgraph_eids=second_subgraph.edata[dgl.EID],
                    subgraph_nweights=second_subgraph.ndata['weight'],
                    subgraph_eweights=second_subgraph.edata['weight'])

# Finish dumping
writer.close()
